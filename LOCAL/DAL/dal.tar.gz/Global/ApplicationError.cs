namespace DAL.Global;

public static class ApplicationError{
    public static string userExists = "user already exists";
    public static string appError = "could not proccess the request";

     public static string requiredParamtersNotSupplied = "required parameters were not supplied";

    public static string notFound = "not found";
}