namespace DAL.Controllers.Request;

public class LessonUpdateRequest {


    public string? Title { get; set; }

    public string? Description { get; set; }
}