namespace DAL.Controllers.Request;

public class VideoLessonCreateRequest{

   
     public int? LessonId { get; set; }

    public string? Title { get; set; }

    public string? Url { get; set; }

}