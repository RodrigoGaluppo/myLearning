namespace DAL.Controllers.Request;

public class CertificateCreateRequest {

    public int CustomercourseId { get; set; }

    public string? Url { get; set; }
}