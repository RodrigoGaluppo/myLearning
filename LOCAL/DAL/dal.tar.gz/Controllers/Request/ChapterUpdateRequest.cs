namespace DAL.Controllers.Request;

public class ChapterUpdateRequest {

     public string? Title { get; set; }
    
}