namespace DAL.Controllers.Request;

public class SubjectCreateRequest {

     public string? Name { get; set; }
}