namespace DAL.Controllers.Request;

public class ResourceLessonCreateRequest{

   
     public int? LessonId { get; set; }

    public string? Title { get; set; }

    public string? Link { get; set; }

}