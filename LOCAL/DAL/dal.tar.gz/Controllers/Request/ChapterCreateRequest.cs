namespace DAL.Controllers.Request;

public class ChapterCreateRequest {

     public string? Title { get; set; }
     public int? CourseId {get;set;}
}