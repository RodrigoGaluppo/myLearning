namespace DAL.Controllers.Request;

public class ChangePasswordRequest {

    public string Password {get;set;}
}