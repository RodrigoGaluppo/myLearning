namespace DAL.Controllers.Request;

public class CustomerChangeImageRequest{
     public string? ImgUrl { get; set; }
}