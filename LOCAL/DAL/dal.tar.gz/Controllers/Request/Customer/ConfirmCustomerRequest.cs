namespace DAL.Controllers.Request;

public class ConfirmCustomerRequest {

    public bool? isConfirmed {get;set;}
}