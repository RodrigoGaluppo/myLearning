namespace DAL.Controllers.Request;

public class CustomerChangeActiveRequest {

    public bool? Active {get;set;}
}