namespace DAL.Controllers.Request;

public class CourseChangeImageRequest{
     public string? ImgUrl { get; set; }
}