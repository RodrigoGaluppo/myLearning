namespace DAL.Controllers.Request;

public class CourseChangeActiveRequest {

    public bool? Active {get;set;}
}