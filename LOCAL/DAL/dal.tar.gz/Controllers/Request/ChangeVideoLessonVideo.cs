namespace DAL.Controllers.Request;

public class ChangeVideoLessonVideo {
    public string? Url { get; set; }
}